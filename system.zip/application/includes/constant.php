<?php
define('DB_NAME','hms2');
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','')
?>
