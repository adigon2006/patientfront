<script src="<?php echo base_url();?>template/vendor/jquery-validation/jquery.validate.min.js"></script>
        <script src="<?php echo base_url();?>template/vendor/Chart.js/Chart.min.js"></script>
        <script src="<?php echo base_url();?>template/assets/js/main.js"></script>
		<script src="<?php echo base_url();?>template/assets/js/index.js"></script>
        <script>
			jQuery(document).ready(function() {
				Main.init();
				Index.init();
				//FormElements.init();
				//FormValidator.init();
			});
		</script>';

		
		
?>		