
<!-- start: MAIN JAVASCRIPTS -->
		<script src="<?php echo base_url();?>template/vendor/jquery/jquery.min.js"></script>
		<script src="<?php echo base_url();?>template/vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url();?>template/vendor/modernizr/modernizr.js"></script>
		<script src="<?php echo base_url();?>template/vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="<?php echo base_url();?>template/vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="<?php echo base_url();?>template/vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
        
        	<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="<?php echo base_url();?>template/vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="<?php echo base_url();?>template/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="<?php echo base_url();?>template/vendor/autosize/autosize.min.js"></script>
		<script src="<?php echo base_url();?>template/vendor/selectFx/classie.js"></script>
		<script src="<?php echo base_url();?>template/vendor/selectFx/selectFx.js"></script>
		<script src="<?php echo base_url();?>template/vendor/select2/select2.min.js"></script>
		<script src="<?php echo base_url();?>template/vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="<?php echo base_url();?>template/vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script><!--
		