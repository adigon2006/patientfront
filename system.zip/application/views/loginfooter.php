<div class="copyright">
&copy; <span class="current-year"></span><span class="text-bold text-uppercase"> <?=$system_name ?></span>. <span>All rights reserved</span>
</div>